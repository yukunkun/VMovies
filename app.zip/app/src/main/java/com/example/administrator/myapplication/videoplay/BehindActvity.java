package com.example.administrator.myapplication.videoplay;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.example.administrator.myapplication.R;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.Call;

public class BehindActvity extends AppCompatActivity {
    String postid;
    WebView webView;
    String request;
    String share;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.behind_actvity);
        Intent intent = getIntent();
        request=intent.getStringExtra("request");
        postid=intent.getStringExtra("postid");
        webView= (WebView) findViewById(R.id.webView);
        init();
        getMessage();
    }

    private void init() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        //设置客服端
        webView.setWebViewClient(new WebViewClient());
        //定义客服端
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl(request);
    }

    private void getMessage() {
        OkHttpUtils.post().url("http://app.vmoiver.com/apiv3/post/view")
                .addParams("postid",postid)
                .build().execute(new StringCallback() {
            @Override
            public void onError(Call call, Exception e) {
                Toast.makeText(getApplicationContext(),"网络连接失败",Toast.LENGTH_LONG).show();
            }

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object=new JSONObject(response);
                    String status = object.optString("status");
                    if(status.equals("0")){
                        JSONObject data = object.optJSONObject("data");
                        JSONObject json = data.optJSONObject("share_link");
                        share = json.optString("qq");


                    }else{
                        Toast.makeText(getApplicationContext(),"下载数据失败",Toast.LENGTH_LONG).show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }
    @Override
    public void onBackPressed() {
        if(webView.canGoBack()){
            webView.goBack();
        }else{
            super.onBackPressed();
        }

    }

    public void back(View view) {
        finish();
    }

    public void share(View view) {
        Intent intent=new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, "分享");
        intent.putExtra(Intent.EXTRA_TEXT,share);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(Intent.createChooser(intent, "分享"));
    }
}
