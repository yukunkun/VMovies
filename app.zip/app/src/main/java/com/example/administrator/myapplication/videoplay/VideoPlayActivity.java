package com.example.administrator.myapplication.videoplay;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

import com.example.administrator.myapplication.R;
import com.example.administrator.myapplication.bean.NewMessage;
import com.google.gson.JsonObject;
import com.jude.swipbackhelper.SwipeBackHelper;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import fm.jiecao.jcvideoplayer_lib.JCVideoPlayerStandard;
import okhttp3.Call;

public class VideoPlayActivity extends Activity {
    WebView webView;
    JCVideoPlayerStandard jcVideoPlayer;
    String videoUri;
    String postId;
    String request;
    String title;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SwipeBackHelper.onCreate(this);
        setContentView(R.layout.activity_video_play);
        Intent intent = getIntent();
        postId=intent.getStringExtra("postId");
        request=intent.getStringExtra("request");
        init();
        OkHttpUtil();
    }

    private void init() {
        jcVideoPlayer= (JCVideoPlayerStandard) findViewById(R.id.jiecao);
        webView= (WebView) findViewById(R.id.play_webview);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        //设置客服端
        webView.setWebViewClient(new WebViewClient());
        //定义客服端
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl(request);
    }

    private void OkHttpUtil() {
        OkHttpUtils.post()
                .url("http://app.vmoiver.com/apiv3/post/view?")
                .addParams("postid",postId)
                .build().execute(new StringCallback() {
            @Override
            public void onError(Call call, Exception e) {
                Toast.makeText(VideoPlayActivity.this, "网络连接失败", Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object=new JSONObject(response);
                    JSONObject object1 = object.optJSONObject("data");
                    JSONObject content = object1.getJSONObject("content");
                    JSONArray video = content.optJSONArray("video");
                    if(video!=null){
                        for (int i = 0; i < video.length(); i++) {
                            JSONObject object2 = video.optJSONObject(i);
                            title=object2.optString("title");
                            videoUri=object2.optString("qiniu_url");
                        }
                        jcVideoPlayer.setUp(videoUri,title);
//                        jcVideoPlayer.ivThumb.setThumbInCustomProject("http://p.qpic.cn/videoyun/0/2449_43b6f696980311e59ed467f22794e792_1/640");

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    protected void onPause() {
        jcVideoPlayer.releaseAllVideos();
        super.onPause();
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        SwipeBackHelper.onPostCreate(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SwipeBackHelper.onDestroy(this);
    }
}