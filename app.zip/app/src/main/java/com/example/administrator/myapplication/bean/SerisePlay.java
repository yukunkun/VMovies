package com.example.administrator.myapplication.bean;

/**
 * Created by Administrator on 2016/5/15.
 */
public class SerisePlay {

    /**
     * seriesid : 97
     * title : 造物集 第三季
     * image : http://cs.vmoiver.com/Uploads/Series/2016-04-01/56fe330e91171.jpg
     * content : 爱摄影，走到哪儿都要带着相机的爸爸；爱臭美，喜欢鼓捣手工护肤品的妈妈；爱撒娇，除了睡觉就是粘人的金毛小公举，一个温暖快乐的三口之家，通过影像记录下日常的手作点滴，取天然花草、原味香料和各种有机食材，经过质朴而简单有趣的手工，作出全家人养护肌肤、疗愈身心的日常用品。一段段抽离忙碌生活的独处时光；一件件带着温暖和自然气息的手作小物，串联成《造物集》中那些恰到好处的幸福光影。
     * weekly : 每周三更新
     * count_follow : 665
     * isfollow : 0
     * share_link : http://www.vmovier.com/series/97?_vfrom=VmovierApp
     * is_end : 0
     * update_to : 7
     * tag_name :
     * post_num_per_seg : 10
     */
        private String seriesid;
        private String title;
        private String image;
        private String content;
        private String weekly;
        private String count_follow;
        private String isfollow;
        private String share_link;
        private String is_end;
        private String update_to;
        private String tag_name;
        private String post_num_per_seg;

        public String getSeriesid() {
            return seriesid;
        }

        public void setSeriesid(String seriesid) {
            this.seriesid = seriesid;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getWeekly() {
            return weekly;
        }

        public void setWeekly(String weekly) {
            this.weekly = weekly;
        }

        public String getCount_follow() {
            return count_follow;
        }

        public void setCount_follow(String count_follow) {
            this.count_follow = count_follow;
        }

        public String getIsfollow() {
            return isfollow;
        }

        public void setIsfollow(String isfollow) {
            this.isfollow = isfollow;
        }

        public String getShare_link() {
            return share_link;
        }

        public void setShare_link(String share_link) {
            this.share_link = share_link;
        }

        public String getIs_end() {
            return is_end;
        }

        public void setIs_end(String is_end) {
            this.is_end = is_end;
        }

        public String getUpdate_to() {
            return update_to;
        }

        public void setUpdate_to(String update_to) {
            this.update_to = update_to;
        }

        public String getTag_name() {
            return tag_name;
        }

        public void setTag_name(String tag_name) {
            this.tag_name = tag_name;
        }

        public String getPost_num_per_seg() {
            return post_num_per_seg;
        }

        public void setPost_num_per_seg(String post_num_per_seg) {
            this.post_num_per_seg = post_num_per_seg;
        }
}
