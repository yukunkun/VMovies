package com.example.administrator.myapplication.bean;

/**
 * Created by Administrator on 2016/5/12.
 */
public class BehindTablayout {
    private String cateid;
    private String catename;

    public void setCateid(String cateid) {
        this.cateid = cateid;
    }

    public void setCatename(String catename) {
        this.catename = catename;
    }

    public String getCateid() {
        return cateid;
    }

    public String getCatename() {
        return catename;
    }
}
