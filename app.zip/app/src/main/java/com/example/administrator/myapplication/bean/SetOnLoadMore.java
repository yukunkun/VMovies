package com.example.administrator.myapplication.bean;

/**
 * Created by Administrator on 2016/5/18.
 */
public interface SetOnLoadMore {
        void  OnLoadMore(int temp);

}
